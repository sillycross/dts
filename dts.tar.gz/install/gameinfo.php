<?php

$gamenum = 0;
$gamestate = 0;
$starttime = 0;
$winmode = 0;
$winner = '';
$arealist = array();
$areanum = 0;
$areatime = 0;
$weather = 0;
$hack = 0;
$validnum = 0;
$alivenum = 0;
$deathnum = 0;

?>