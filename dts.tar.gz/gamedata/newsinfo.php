<? if(!defined('IN_GAME')) exit('Access Denied'); ?>
