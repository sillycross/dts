<?php

if(!defined('IN_GAME')){exit('Access Denied');}

$hdamage = 97806969;
$hplayer = 'lemon';
$noisetime = 1435643670;
$noisepls = 30;
$noiseid = 354;
$noiseid2 = 30;
$noisemode = 'd';

?>