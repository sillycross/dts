<?php

define('CURSCRIPT', 'bugfixlist');
require './include/common.inc.php';


include template('bugfixlist');

?>

