<?php

namespace gameflow_antiafk
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys map gameflow_base';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/gameflow_antiafk.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
