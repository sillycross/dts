<?php

namespace gameflow_antiafk
{
	//反挂机系统间隔时间，单位分钟
	$antiAFKertime = 10;
}

?>