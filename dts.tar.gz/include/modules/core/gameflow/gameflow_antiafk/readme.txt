自动反挂机模块。

gamestate>=40时开始判定。

