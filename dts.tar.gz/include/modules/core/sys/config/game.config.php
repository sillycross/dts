<?php

namespace sys
{

	/*Game Config*/

	//胜率榜最小参赛次数
	$winratemingames = 10;

	//本局游戏人数限制
	$validlimit = 300;
	
	// 初始耐力最大值 
	$splimit = 400;
	// 初始生命最大值 
	$hplimit = 400;

	//hack基础成功率
	$hack_obbs = 40;

}

?>