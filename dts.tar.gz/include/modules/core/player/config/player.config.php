<?php

namespace player
{
	$typeinfo = Array(
		0=>'参战者',
	);
	
	$killmsginfo = Array(
		0=>'',
	);
	
	$lwinfo = Array(
		0 => '',
	);
	
	$sexinfo = Array(0=> '未定', 'm' => '男生', 'f' => '女生');
	
	$equip_list = Array();
	
	$battle_equip_list = Array();
	
}
		
