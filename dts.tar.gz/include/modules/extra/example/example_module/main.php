<?php

namespace modulename
{
	function init()
	{
	}
}

?>
