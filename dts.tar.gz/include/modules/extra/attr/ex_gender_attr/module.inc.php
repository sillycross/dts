<?php

namespace ex_gender_attr
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys itemmain logger skillbase attrbase weapon ex_phy_nullify';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/ex_dmg_att.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
