<?php

namespace ex_dmg_att
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys itemmain logger skillbase attrbase weapon';
	$___MODULE_dependency_optional = 'skill5 skill6 skill7 skill8 skill9 noise';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/ex_dmg_att.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
