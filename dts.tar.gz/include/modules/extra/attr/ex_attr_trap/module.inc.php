<?php

namespace ex_attr_trap
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player logger itemmain';
	$___MODULE_dependency_optional = 'trap';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
