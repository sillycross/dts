<?php

namespace ex_rapid_attr
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'attrbase weapon itemmain logger';
	$___MODULE_dependency_optional = 'wound';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
