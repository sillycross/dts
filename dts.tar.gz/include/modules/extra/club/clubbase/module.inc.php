<?php

namespace clubbase
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player logger enemy attack';
	$___MODULE_dependency_optional = 'battle';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/clubbase.config.php';
	$___MODULE_templatelist = 'club_profile skilldesc_start skilldesc_mid1 skilldesc_mid2 skilldesc_end skillpage profileskillpage skillpage_profile';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
