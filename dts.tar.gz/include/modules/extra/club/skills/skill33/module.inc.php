<?php

namespace skill33
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'skillbase player weapon armor logger input';
	$___MODULE_dependency_optional = 'skill32';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = 'desc';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
