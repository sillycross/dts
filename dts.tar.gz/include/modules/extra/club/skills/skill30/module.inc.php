<?php

namespace skill30
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'skillbase player attrbase weapon sys logger';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = 'desc battlecmd';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
