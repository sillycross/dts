<?php

namespace dualwep
{
	$dualwep_iteminfo=Array(
		'WGK' => '枪刃',
		'WCF' => '灵弹',
		'WFK' => '烈刃',
		'WKP' => '暴斩',
		'WCP' => '巨力',
		'WDG' => '重炮',
	);
}

?>
