<?php

namespace wep_j
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'weapon itemmain wep_p';
	$___MODULE_dependency_optional = 'noise';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
