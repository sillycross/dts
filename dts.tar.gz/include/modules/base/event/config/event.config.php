<?php

namespace event
{
	//随机事件几率(百分比)
	$event_obbs = 4;
}

?>
