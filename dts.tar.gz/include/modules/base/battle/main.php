<?php

namespace battle
{
	function init() {}
}

?>
