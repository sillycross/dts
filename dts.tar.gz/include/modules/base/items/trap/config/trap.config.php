<?php

namespace trap
{
	//强制踩陷阱最小几率(百分比)
	$trap_min_obbs = 1;
	//强制踩陷阱最大几率(百分比)
	$trap_max_obbs = 40;
}

?>
