<?php

namespace ammunition
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player itemmain logger weapon';
	$___MODULE_dependency_optional = 'wep_g wep_j';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
