<?php

namespace cooldown
{
	//是否启动冷却时间，0为不启动，1为启动；
	$coldtimeon = 1;
	//是否显示冷却时间倒计时，0为不显示，1为显示；
	$showcoldtimer = 1;
	//移动的冷却时间，单位微秒
	$movecoldtime=900;
	//探索的冷却时间，单位微秒
	$searchcoldtime=900;
	//使用物品的冷却时间，单位微秒
	$itemusecoldtime=300;
}

?>
