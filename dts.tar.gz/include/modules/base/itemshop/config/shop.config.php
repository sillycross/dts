<?php

namespace itemshop
{
	//哪里有商店
	$shops = Array(0,14,27); 
}

?>