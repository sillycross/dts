<?php

namespace armor
{
	//■ 无限耐久度 ■
	$nosta = '∞';
	
	//■ 无防具 ■
	$noarb = '内衣';
	
	$armor_equip_list = Array('arb','arh','ara','arf');
	
	$armor_iteminfo = Array(
		'DN' => '内衣',#内衣
		'DB' => '身体装备',
		'DH' => '头部装备',
		'DA' => '手臂装备',
		'DF' => '腿部装备',
	);
}

?>
