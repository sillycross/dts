请务必阅读skillbase模块的readme.txt！！ 

所有技能的私有函数都应该以自己的技能编号为后缀，防止冲突
