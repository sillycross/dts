<?php

namespace rest
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player logger';
	$___MODULE_dependency_optional = 'wound';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/rest.config.php';
	$___MODULE_templatelist = 'rest_cmd';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
