<?php

namespace armor_art
{
	$armor_art_equip_list = Array('art');
	
	$armor_art_iteminfo = Array(
		'A'  => '饰物',
		'Ag' => '同志饰物',
		'Al' => '热恋饰物',
	);
}

?>
