<?php

namespace corpse
{
	//尸体发现几率（百分比）
	$corpse_obbs = 50;
	
	//尸体保护时间，单位秒
	$corpseprotect = 10;
}

?>
