<?php

namespace team
{
	//创建队伍需要的体力
	$team_sp = 200;
	//加入队伍需要的体力
	$teamj_sp = 100;
	//队伍最大人数
	$teamlimit = 5;
}

?>
