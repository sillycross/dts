<?php

namespace team
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys map logger player metman enemy input';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php team.command.php config/team.config.php';
	$___MODULE_templatelist = 'findteam team team_command';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
