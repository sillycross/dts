<?php

namespace metman
{
	$hpinfo = Array('并无大碍','伤痕累累','生命危险','已经死亡');
	$spinfo = Array('精力充沛','略有疲惫','精疲力尽','已经死亡');
	$rageinfo = Array('平静','愤怒','暴怒','已经死亡');
	$wepeinfo = Array('不值一提','略有威胁','威力可观','无敌神器');
	
	//发现活人基础几率(百分比)
	$metman_obbs = 70;
}

?>
