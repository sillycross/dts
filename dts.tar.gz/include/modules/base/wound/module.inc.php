<?php

namespace wound
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player logger skillbase';
	$___MODULE_dependency_optional = 'battle weapon metman';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/wound.config.php';
	$___MODULE_templatelist = 'wound_profile wound_picture';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
