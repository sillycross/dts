<?php

namespace weather
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys map itemmain player logger';
	$___MODULE_dependency_optional = 'metman enemy explore weapon radar pose tactic';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/weather.config.php';
	$___MODULE_templatelist = 'profile_weather';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
