<?php

namespace noise
{
	$noiseinfo = Array(
		'Crow Song'=>'Crow Song',
		'Alicemagic'=>'Alicemagic',
		);

	//枪声间隔时间(秒)
	$noiselimit = 300;
}

?>
