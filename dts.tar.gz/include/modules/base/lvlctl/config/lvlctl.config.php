<?php

namespace lvlctl
{
	// 等级提升基本经验值 
	$baseexp = 9;
}

?>
