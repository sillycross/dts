<?php

namespace addnpc
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player map logger npc itemmain weather lvlctl';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/addnpc.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
