<?php

namespace explore
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys input map logger player';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/explore.config.php';
	$___MODULE_templatelist = 'explore';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
