<?php

namespace npc
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys map player lvlctl';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php config/npc.data.config.php config/npc.resource.config.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
