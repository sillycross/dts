<?php

namespace itemmain
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys player logger input';
	$___MODULE_dependency_optional = 'explore';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php itemuse.php itemcmd.php config/itemmain.config.php';
	$___MODULE_templatelist = 'itemmerge itemmove itemdrop itemmerge0 itemdrop0 itemfind itmcommand profile_equipments profile_backpack';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
