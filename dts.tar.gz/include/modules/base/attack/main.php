<?php

namespace attack
{
	function init() {}
}

?>
