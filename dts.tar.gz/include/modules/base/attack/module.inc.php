<?php

namespace attack
{
	////////// MODULE HEADER START ///////////////
	$___MODULE_dependency = 'sys map player battle';
	$___MODULE_dependency_optional = '';
	$___MODULE_conflict = '';
	$___MODULE_codelist = 'main.php attack_wrapper.php attack.php attack_news.php';
	$___MODULE_templatelist = '';
	////////// MODULE HEADER END /////////////////
	require __INIT_MODULE__(__NAMESPACE__,__DIR__);
}

?>
