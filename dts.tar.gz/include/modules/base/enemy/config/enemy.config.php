<?php

namespace enemy
{
	//基础先攻率
	$active_obbs = 50;
}

?>
