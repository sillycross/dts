<?php

define('CURSCRIPT', 'newfeature');
require './include/common.inc.php';


include template('newfeature');

?>

