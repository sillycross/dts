<?php

define('CURSCRIPT', 'announce');
require './include/common.inc.php';


include template('announce');

?>

